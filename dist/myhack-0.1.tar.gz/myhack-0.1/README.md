## myhack
This library was created for the analyse hackathon

## building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git+https://github.com/neosenokwane/myhack'

## updating this package from GitHub
'pip install --upgrade git+https://github.com/neosenokwane/myhack'
